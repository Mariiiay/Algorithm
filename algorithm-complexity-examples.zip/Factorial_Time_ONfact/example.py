import itertools

def all_permutations(arr):
    return list(itertools.permutations(arr))