def get_first_element(lst):
    return lst[0]