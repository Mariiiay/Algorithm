# Примеры сложности алгоритмов (Big-O)

Здесь собраны примеры базовых алгоритмов с разной сложностью:
- O(1): Константное время
- O(log N): Логарифмическое
- O(N): Линейное
- O(N log N): Линейно-логарифмическое
- O(N²): Квадратичное
- O(N³): Кубическое
- O(2^N): Экспоненциальное
- O(N!): Факториальное

Каждый пример снабжен простым объяснением и кодом.

📁 Навигация по папкам:
- `Constant_Time_O1/`
- `Logarithmic_Time_OlogN/`
- `Linear_Time_ON/`
- `Linearithmic_Time_ONlogN/`
- `Quadratic_Time_ON2/`
- `Cubic_Time_ON3/`
- `Exponential_Time_O2N/`
- `Factorial_Time_ONfact/`
